extends CanvasLayer
@onready var water_val_dis: Label= $LabelWater/WaterVal
@onready var food_val_dis: Label= $LabelFood/FoodVal
@onready var fun_val_dis: Label= $LabelFun/FunVal

@onready var mood_dis_good = preload("res://moodgood.png")
@onready var mood_dis_mid = preload("res://moodmid.png")
@onready var mood_dis_bad = preload("res://moodbad.png")
@onready var mood_dis_dead = preload("res://mooddead.png")

var water_val = 100
var food_val = 100
var fun_val = 100

var rng = RandomNumberGenerator.new()

func fun_button_pressed() ->void:
	if fun_val < 100:
		fun_val +=1

func water_button_pressed() ->void:
	if water_val < 100:
		water_val+=1

func food_button_pressed() ->void:
	if food_val < 100:
		food_val+=1

func _process(_delta: float) -> void:
	water_val_dis.text = str(water_val)
	food_val_dis.text = str(food_val)
	fun_val_dis.text = str(fun_val)
	
	var total_score = food_val + fun_val + water_val
	if total_score >= 200:
		$Sprite2D.texture = mood_dis_good
	elif total_score >= 100 and total_score < 200:
		$Sprite2D.texture = mood_dis_mid
	elif total_score >= 1 and total_score <100:
		$Sprite2D.texture = mood_dis_bad

	if total_score == 0 or food_val == 0 or fun_val == 0 or water_val == 0:
		$Sprite2D.texture = mood_dis_dead
		await get_tree().create_timer(10.0).timeout
		get_tree().quit()

func _on_timer_timeout() -> void:
	var random_nmbr = rng.randf_range(0, 3)
	if random_nmbr < 1:
		var random_hit = rng.randf_range(0, 5)
		if random_hit > 3.5:
			water_val-= 1
	elif random_nmbr< 2: 
		var random_hit = rng.randf_range(0, 5)
		if random_hit > 3.5:
			food_val-= 1
	else:
		var random_hit = rng.randf_range(0, 5)
		if random_hit > 3.5:
			fun_val-= 1
